package com.example.appgithubuser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class UserAdapter(private val listUser: List<User>) : RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    class ViewHolder (view: View) : RecyclerView.ViewHolder(view) {
        val tvUser: TextView = view.findViewById(R.id.tvUser)
        val profileUser: ImageView = view.findViewById(R.id.profileUser)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int) =
        ViewHolder(LayoutInflater.from(viewGroup.context).inflate(R.layout.item_user, viewGroup, false))



    override fun onBindViewHolder(holder: UserAdapter.ViewHolder, position: Int) {
        val list = listUser[position]
        holder.tvUser.text = listUser[position].login
        Glide.with(holder.itemView.context)
            .load(listUser[position].avatar_url)
            .into(holder.profileUser)
    }


    override fun getItemCount(): Int = listUser.size

}