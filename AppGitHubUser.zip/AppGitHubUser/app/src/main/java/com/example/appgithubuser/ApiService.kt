package com.example.appgithubuser

import retrofit2.Call
import retrofit2.http.*

interface ApiService {
//    @GET("detail/{id}")
//    fun getUser(
//        @Path("id") id: String
//    ): Call<GithubResponse>

    @GET("search/users")
    fun searchUser(
        @Query("q") query: String
    ): Call<SearchResponse>
}